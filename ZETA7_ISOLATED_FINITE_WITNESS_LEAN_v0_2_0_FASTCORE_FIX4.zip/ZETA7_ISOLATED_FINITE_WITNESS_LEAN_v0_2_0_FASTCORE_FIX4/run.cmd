@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "PACKAGE=ZETA7_ISOLATED_FINITE_WITNESS_LEAN_v0_2_0_FASTCORE_FIX4"
set "LEAN_EXE=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0\bin\lean.exe"
set "CACHE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
set "MATHLIB_ROOT=%CACHE_ROOT%\.lake\packages\mathlib"
set "LEAN_JOBS=16"

cd /d "%~dp0"

echo PACKAGE=%PACKAGE%
echo RUNNER=NATIVE_WINDOWS_LEAN_433_FASTCORE
echo NETWORK=NOT_USED
echo LAKE=NOT_USED
echo PYTHON=NOT_USED
echo POWERSHELL=NOT_USED
echo WSL=NOT_USED
echo LEAN_THREADS=%LEAN_JOBS%

if not exist "%LEAN_EXE%" (
  echo ERROR=LEAN_EXE_NOT_FOUND
  echo EXPECTED="%LEAN_EXE%"
  exit /b 2
)

if not exist "%MATHLIB_ROOT%\.lake\build\lib\lean" (
  echo ERROR=MATHLIB_CACHE_NOT_FOUND
  echo EXPECTED="%MATHLIB_ROOT%\.lake\build\lib\lean"
  exit /b 3
)

echo CACHE_ROOT=%CACHE_ROOT%
echo MATHLIB_CACHE=READY

set "LEAN_PATH=%CD%\build;%CACHE_ROOT%\.lake\build\lib\lean;%MATHLIB_ROOT%\.lake\build\lib\lean"
for /D %%D in ("%CACHE_ROOT%\.lake\packages\*") do (
  if exist "%%~fD\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fD\.lake\build\lib\lean"
)

if not exist "build\Zeta7Isolated" mkdir "build\Zeta7Isolated"

echo MODE=FASTCORE
call :compile Zeta7Isolated\Core.lean build\Zeta7Isolated\Core.olean
if errorlevel 1 exit /b 1
call :compile Zeta7Isolated\Channel.lean build\Zeta7Isolated\Channel.olean
if errorlevel 1 exit /b 1
call :compile Zeta7Isolated\Candidates.lean build\Zeta7Isolated\Candidates.olean
if errorlevel 1 exit /b 1
call :compile Zeta7Isolated\Witness.lean build\Zeta7Isolated\Witness.olean
if errorlevel 1 exit /b 1
call :compile Zeta7Isolated\Audit.lean build\Zeta7Isolated\Audit.olean
if errorlevel 1 exit /b 1
call :compile Main.lean build\Main.olean
if errorlevel 1 exit /b 1

echo SORRYAX=NONE_EXPECTED
echo RUN=PASS
exit /b 0

:compile
set "SRC=%~1"
set "OUT=%~2"
echo CHECK=%SRC%
"%LEAN_EXE%" -j %LEAN_JOBS% -o "%OUT%" "%SRC%"
if errorlevel 1 (
  echo RUN=FAIL
  exit /b 1
)
exit /b 0
