# ZETA7_ISOLATED_FINITE_WITNESS_LEAN_v0_2_0_FASTCORE

Adds a fully explicit finite witness for the actual Mathlib Riemann zeta value at 7:

    0 < 9293 - 9216 * zeta7Real

where `zeta7Real = (riemannZeta 7).re`.

The proof uses only Mathlib's Dirichlet-series identity for ζ(7), the integral test for the tail after n=5, and rational arithmetic. It also packages the witness as the integer polynomial

    Q1(X) = 9293 - 9216 X

and proves `0 < evalIntPoly Q1 zeta7Real`.

This is a finite witness only. It does not claim irrationality of ζ(7) by itself and does not supply the missing shrinking sequence required by `PolynomialShrinkCertificate`.

No project axioms and no `sorry` are intended.


FIX3: explicit Complex.ofReal_div term cast; literal 6-1=5 interval normalization.

FIX4: replace termwise complex-real simplification by exact rewrite through the proved `hcast`, followed by definitional reduction (`rfl`).
