import Mathlib

open Filter

namespace Zeta7Isolated

/-- The real part of the Riemann zeta value at `7`. -/
noncomputable def zeta7Real : ℝ := (riemannZeta 7).re

private lemma not_irrational_exists_rep {x : ℝ} :
    ¬ Irrational x → ∃ (a : ℤ) (b : ℕ), 0 < b ∧ x = (a : ℝ) / (b : ℝ) := by
  intro hx
  obtain ⟨q, hq⟩ := exists_rat_of_not_irrational hx
  refine ⟨q.num, q.den, q.pos, ?_⟩
  calc
    x = (q : ℝ) := hq
    _ = (q.num : ℝ) / (q.den : ℝ) := Rat.cast_def q

/-- Evaluate an integer polynomial at a real point. -/
def evalIntPoly (P : Polynomial ℤ) (x : ℝ) : ℝ :=
  Polynomial.eval₂ (Int.castRingHom ℝ) x P

/--
An isolated polynomial certificate for one real number.

The unresolved zeta(7) frontier is the construction of one inhabitant of this
structure for `zeta7Real`.  In particular, `scaled_integer` and
`scaled_tendsto_zero` are explicit obligations, not hidden axioms.
-/
structure PolynomialShrinkCertificate (x : ℝ) where
  Q : ℕ → Polynomial ℤ
  d : ℕ → ℕ
  degree_le : ∀ n, (Q n).natDegree ≤ d n
  positive : ∀ n, 0 < evalIntPoly (Q n) x
  scaled_integer :
    ∀ (a : ℤ) (b : ℕ), 0 < b →
      x = (a : ℝ) / (b : ℝ) →
      ∀ n, ∃ z : ℤ,
        (b : ℝ) ^ (d n) * evalIntPoly (Q n) x = z
  scaled_tendsto_zero :
    ∀ (b : ℕ), 0 < b →
      Tendsto
        (fun n => (b : ℝ) ^ (d n) * evalIntPoly (Q n) x)
        atTop (nhds 0)

/--
Integer-gap closure: an isolated shrinking polynomial certificate forces
irrationality of its target.
-/
theorem irrational_of_polynomialShrinkCertificate {x : ℝ}
    (C : PolynomialShrinkCertificate x) : Irrational x := by
  by_contra hrat
  obtain ⟨a, b, hb, hab⟩ := not_irrational_exists_rep hrat
  let u : ℕ → ℝ := fun n => (b : ℝ) ^ (C.d n) * evalIntPoly (C.Q n) x
  have hu_pos : ∀ n, 0 < u n := by
    intro n
    have hbR : (0 : ℝ) < (b : ℝ) := by exact_mod_cast hb
    exact mul_pos (pow_pos hbR _) (C.positive n)
  have hu_int : ∀ n, ∃ z : ℤ, u n = z := by
    intro n
    simpa [u] using C.scaled_integer a b hb hab n
  have hu_zero : Tendsto u atTop (nhds 0) := by
    simpa [u] using C.scaled_tendsto_zero b hb
  have hu_lt_one : ∀ᶠ n : ℕ in atTop, u n < 1 := by
    exact hu_zero (Iio_mem_nhds (by norm_num : (0 : ℝ) < 1))
  obtain ⟨n, hn⟩ := hu_lt_one.exists
  obtain ⟨z, hz⟩ := hu_int n
  have hz_pos_real : (0 : ℝ) < (z : ℝ) := by
    rw [← hz]
    exact hu_pos n
  have hz_lt_real : (z : ℝ) < 1 := by
    rw [← hz]
    exact hn
  have hz_pos : (0 : ℤ) < z := by exact_mod_cast hz_pos_real
  have hz_lt : z < (1 : ℤ) := by exact_mod_cast hz_lt_real
  omega

/-- The isolated zeta(7) closure theorem. -/
theorem irrational_zeta7Real_of_certificate
    (C : PolynomialShrinkCertificate zeta7Real) : Irrational zeta7Real :=
  irrational_of_polynomialShrinkCertificate C

end Zeta7Isolated
