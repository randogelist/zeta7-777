import Mathlib
import Zeta7Isolated.Core

namespace Zeta7Isolated

/-- First concrete finite zeta(7) search polynomial recovered in this branch. -/
noncomputable def Q2 : Polynomial ℤ :=
  Polynomial.C (-4399 : ℤ)
    + Polynomial.C (13656 : ℤ) * Polynomial.X
    + Polynomial.C (-9216 : ℤ) * Polynomial.X ^ 2

/-- Second concrete finite zeta(7) search polynomial recovered in this branch. -/
noncomputable def Q3 : Polynomial ℤ :=
  Polynomial.C (36535857733 : ℤ)
    + Polynomial.C (-177407264160 : ℤ) * Polynomial.X
    + Polynomial.C (244062203904 : ℤ) * Polynomial.X ^ 2
    + Polynomial.C (-103195607040 : ℤ) * Polynomial.X ^ 3

/-- Kernel-checked real evaluation formula for `Q2`. -/
theorem eval_Q2 (x : ℝ) :
    evalIntPoly Q2 x =
      -9216 * x ^ 2 + 13656 * x - 4399 := by
  simp [evalIntPoly, Q2]
  ring

/-- Kernel-checked real evaluation formula for `Q3`. -/
theorem eval_Q3 (x : ℝ) :
    evalIntPoly Q3 x =
      -103195607040 * x ^ 3
        + 244062203904 * x ^ 2
        - 177407264160 * x
        + 36535857733 := by
  simp [evalIntPoly, Q3]
  ring

/-- These are finite search witnesses only; no positivity/decay claim is made here. -/
structure FiniteCandidate where
  P : Polynomial ℤ
  degreeBound : ℕ
  degree_le : P.natDegree ≤ degreeBound

noncomputable def candidateQ2 : FiniteCandidate where
  P := Q2
  degreeBound := Q2.natDegree
  degree_le := le_rfl

noncomputable def candidateQ3 : FiniteCandidate where
  P := Q3
  degreeBound := Q3.natDegree
  degree_le := le_rfl

end Zeta7Isolated
