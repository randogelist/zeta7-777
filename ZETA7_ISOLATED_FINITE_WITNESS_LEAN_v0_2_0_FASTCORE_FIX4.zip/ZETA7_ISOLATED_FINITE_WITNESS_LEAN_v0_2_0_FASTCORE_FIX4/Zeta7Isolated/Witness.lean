import Mathlib
import Zeta7Isolated.Core
import Zeta7Isolated.Candidates

open scoped BigOperators
open Filter Set MeasureTheory

namespace Zeta7Isolated

/-- Real Dirichlet-series realization of `zeta7Real`. -/
theorem zeta7Real_eq_real_tsum :
    zeta7Real = ∑' n : ℕ, (1 : ℝ) / (n : ℝ) ^ 7 := by
  have hz : riemannZeta (7 : ℂ) =
      ∑' n : ℕ, (1 : ℂ) / (n : ℂ) ^ 7 :=
    zeta_nat_eq_tsum_of_gt_one (k := 7) (by norm_num)
  have hsR : Summable (fun n : ℕ => (1 : ℝ) / (n : ℝ) ^ 7) :=
    (Real.summable_one_div_nat_pow (p := 7)).2 (by norm_num)
  have hsC : Summable (fun n : ℕ => (1 : ℂ) / (n : ℂ) ^ 7) := by
    have h := (Complex.summable_ofReal).2 hsR
    simpa using h
  calc
    zeta7Real = (riemannZeta (7 : ℂ)).re := rfl
    _ = (∑' n : ℕ, (1 : ℂ) / (n : ℂ) ^ 7).re := by rw [hz]
    _ = ∑' n : ℕ, ((1 : ℂ) / (n : ℂ) ^ 7).re := Complex.re_tsum hsC
    _ = ∑' n : ℕ, (1 : ℝ) / (n : ℝ) ^ 7 := by
      congr 1
      funext n
      have hpow :
          ((((n : ℝ) ^ 7 : ℝ) : ℂ)) = (n : ℂ) ^ 7 := by
        simpa only [Complex.ofRealHom_eq_coe, Complex.ofReal_natCast] using
          (map_pow Complex.ofRealHom (n : ℝ) 7)
      have hcast :
          (1 : ℂ) / (n : ℂ) ^ 7 =
            (((1 : ℝ) / (n : ℝ) ^ 7 : ℝ) : ℂ) := by
        rw [← hpow]
        simpa using (Complex.ofReal_div (1 : ℝ) ((n : ℝ) ^ 7)).symm
      rw [hcast]
      rfl

private noncomputable def tailFun (x : ℝ) : ℝ := x ^ (-7 : ℝ)

private theorem tailFun_nat (n : ℕ) :
    tailFun n = (1 : ℝ) / (n : ℝ) ^ 7 := by
  by_cases hn : n = 0
  · subst n
    simp [tailFun]
  · have hnR : (0 : ℝ) ≤ (n : ℝ) := by positivity
    rw [tailFun, show (-7 : ℝ) = -(7 : ℝ) by norm_num,
      Real.rpow_neg hnR]
    simp [one_div]

private theorem tailFun_antitone :
    AntitoneOn tailFun (Set.Ici (5 : ℝ)) := by
  apply (Real.antitoneOn_rpow_Ioi_of_exponent_nonpos
    (show (-7 : ℝ) ≤ 0 by norm_num)).mono
  intro x hx
  exact lt_of_lt_of_le (by norm_num : (0 : ℝ) < 5) hx

private theorem tailFun_integrable :
    IntegrableOn tailFun (Set.Ioi (((6 : ℕ) : ℝ) - 1)) := by
  change IntegrableOn (fun x : ℝ => x ^ (-7 : ℝ))
    (Set.Ioi (((6 : ℕ) : ℝ) - 1))
  exact integrableOn_Ioi_rpow_of_lt (a := (-7 : ℝ))
    (by norm_num) (by norm_num)

private theorem tailFun_nonneg :
    ∀ t ∈ Set.Ioi (((6 : ℕ) : ℝ) - 1), 0 ≤ tailFun t := by
  intro t ht
  exact Real.rpow_nonneg (le_of_lt (lt_trans (by norm_num : (0 : ℝ) < ((6 : ℕ) : ℝ) - 1) ht)) _

private theorem tailFun_integral :
    (∫ x : ℝ in Set.Ioi (5 : ℝ), tailFun x) =
      (1 : ℝ) / (6 * 5 ^ 6) := by
  rw [show (∫ x : ℝ in Set.Ioi (5 : ℝ), tailFun x) =
      ∫ x : ℝ in Set.Ioi (5 : ℝ), x ^ (-7 : ℝ) by rfl]
  rw [integral_Ioi_rpow_of_lt (a := (-7 : ℝ))
    (by norm_num) (show (0 : ℝ) < 5 by norm_num)]
  norm_num [Real.rpow_neg]

/-- Certified elementary upper bound for `ζ(7)` from five terms plus an integral tail. -/
theorem zeta7Real_le_five_term_bound :
    zeta7Real ≤
      (1 : ℝ)
      + 1 / 2 ^ 7
      + 1 / 3 ^ 7
      + 1 / 4 ^ 7
      + 1 / 5 ^ 7
      + 1 / (6 * 5 ^ 6) := by
  have hfive : (((6 : ℕ) : ℝ) - 1) = (5 : ℝ) := by norm_num
  have hanti6 : AntitoneOn tailFun (Set.Ici (((6 : ℕ) : ℝ) - 1)) := by
    rw [hfive]
    exact tailFun_antitone
  have htail := hanti6.abs_tsum_sub_sum_range_le_integral
    (N := 6) (by norm_num) tailFun_integrable tailFun_nonneg
  rw [hfive] at htail
  have hle :
      (∑' n : ℕ, tailFun n) - (∑ n ∈ Finset.range 6, tailFun n)
        ≤ (∫ x : ℝ in Set.Ioi (5 : ℝ), tailFun x) := by
    exact le_trans (le_abs_self _) htail
  rw [tailFun_integral] at hle
  have htsum : (∑' n : ℕ, tailFun n) = zeta7Real := by
    rw [zeta7Real_eq_real_tsum]
    apply tsum_congr
    intro n
    exact tailFun_nat n
  rw [htsum] at hle
  norm_num [tailFun, Real.rpow_neg] at hle ⊢
  linarith

/-- A fully rational upper bound strictly below the zero of `9293 - 9216 X`. -/
theorem zeta7Real_lt_9293_div_9216 :
    zeta7Real < (9293 : ℝ) / 9216 := by
  have h := zeta7Real_le_five_term_bound
  have hrat :
      (1 : ℝ)
        + 1 / 2 ^ 7
        + 1 / 3 ^ 7
        + 1 / 4 ^ 7
        + 1 / 5 ^ 7
        + 1 / (6 * 5 ^ 6)
      < (9293 : ℝ) / 9216 := by
    norm_num
  exact lt_of_le_of_lt h hrat

/-- The isolated finite zeta(7) witness found by the determinant search. -/
theorem finite_zeta7_witness :
    0 < (9293 : ℝ) - 9216 * zeta7Real := by
  have h := zeta7Real_lt_9293_div_9216
  nlinarith

/-- The same witness packaged as the value of the integer polynomial `9293 - 9216 X`. -/
noncomputable def Q1 : Polynomial ℤ :=
  Polynomial.C (9293 : ℤ) + Polynomial.C (-9216 : ℤ) * Polynomial.X

theorem eval_Q1 (x : ℝ) :
    evalIntPoly Q1 x = 9293 - 9216 * x := by
  simp [evalIntPoly, Q1]
  ring

theorem eval_Q1_zeta7_pos :
    0 < evalIntPoly Q1 zeta7Real := by
  rw [eval_Q1]
  exact finite_zeta7_witness

end Zeta7Isolated
